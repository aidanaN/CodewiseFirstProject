package operators;

public class UnaryOperators {
    public static void main (String [] args) {
        //Unary operators
        //++, +=
        //--, -=
        //*=, /=

        int a = 5;
        int b = 10;

        a = ++a;
        a = 1+5;

        System.out.println(a + b);
        System.out.println(++a);

        // ++x - prefix;
        // x++ - postfix;





    }
}
