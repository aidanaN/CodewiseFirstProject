package dataTypes;


public class homeassignment {
    public static void main (String [] args){

        byte weather = 6;
        System.out.println("Today's weather is "  + weather + " in celsius degree");
        short myCar = 32000;
        System.out.println("Selling our car for " + myCar +" dollars");
        int house = 600000;
        System.out.println("Buying house for " + house +" dollars");
        long mySalary = 160000;
        System.out.println("My annual salary is " + mySalary + " dollars");
        double city = 2696555;
        System.out.println("Current population in Chicago is  " + city + " people");
        float fah = 43.5f;
        System.out.println("Forecast shows " + fah + " fahrenheit degree");
        boolean isTrue=true;
        System.out.println("Chicago is the third largest city in USA, it is  " + isTrue);
        boolean isFalse=false;
        System.out.print("Golden gate located in Chicago. It is " + isFalse);


        char unitNumber = '5';
        char unitLetter = 'c';
        char unitSymbol='?';
        unitLetter = 'C';
        System.out.println("Is your apt number is " + unitNumber + unitLetter + unitSymbol);

        String homework = "Good evening, this is my first Home assignment";
        System.out.println(homework);

        String p = "primitive";
        String np = "non primitive";

        System.out.println("Today we learn 2 types of date structures: " + p+ " and "+ np);

        String name = "Aidana";
        String lastName = "Nugumetova";
        String age = "27";
        System.out.println("Good evening, my name is " + name + " " + lastName + " and I am " + age + " years old");

        byte b = 100;
        short s = 123;
        int v = 123543;
        int calc = -9876345;
        long amountVal = 1234567891;
        float interestRate = 12.25f;
        double sineVal= 12345.234d;
        boolean flag = true;
        boolean val = false;
        char ch1= 88;
        char ch2='Y';

        System.out.println("byte Value = " + b);
        System.out.println("short Value = " + s);
        System.out.println("int Value = " + v);
        System.out.println("inc newValue =" + calc);
        System.out.println("long Value = " + amountVal);
        System.out.println("float Value = " + interestRate);
        System.out.println("double Value = " + sineVal);
        System.out.println("boolean Value = " + flag);
        System.out.println("boolean newValue = " + val);
        System.out.println("char Value = " + ch1);
        System.out.println("char newValue = " + ch2);























    }




}
